const express = require('express');
const mongoose = require('mongoose');
const app = express();
const cors = require('cors');
const dotenv = require('dotenv')
const path = require('path');
const { log } = require('console');


app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/LoginDB");


const userSchema = new mongoose.Schema({
   email:String,
   password:String
})



const  userModel = mongoose.model("users",userSchema)


app.post("/LoginDB", (req, res) => {
    const { email, password } = req.body;
    console.log("Received request:", { email, password });

    if (!email || !password) {
        return res.status(400).json("Invalid email or password");
    }

   
    try {
        const user = userModel.findOne({ email: email.toLowerCase().trim() });

        if (user) {;
    console.log(user,"data---");
            if (user) {
                console.log("Login Successfully");
                return res.json("Login Successfully");
            } else {
                console.log("The password is incorrect");
                return res.json("The password is incorrect");
            }
        } else {
            console.log("No record exists");
            return res.json("No record exists");
        }
    } catch (error) {
        console.error("Database error:", error);
        return res.status(500).json("Internal Server Error");
    }
});


dotenv.config({path:path.join(__dirname,"congif","config.env")})

app.listen(process.env.PORT,()=>{
    console.log(`server listing PORT ${process.env.PORT} in  ${process.env.NODE_ENV}`)
})